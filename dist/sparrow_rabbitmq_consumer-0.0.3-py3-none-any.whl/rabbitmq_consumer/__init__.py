name = "rabbitmq_consumer"

from .rabbitmq_consumer import *